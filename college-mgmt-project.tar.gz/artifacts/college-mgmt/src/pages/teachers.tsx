import React, { useState } from "react";
import { useTeachers, useCreateTeacher, useUpdateTeacher, useDeleteTeacher } from "@/hooks/use-teachers";
import { PageHeader, Card, Table, Th, Tr, Td, Button, Input, Select, Modal, Badge } from "@/components/ui-elements";
import { Plus, Search, Edit2, Trash2, Loader2, AlertCircle } from "lucide-react";
import { motion } from "framer-motion";
import type { Teacher, CreateTeacherRequest } from "@workspace/api-client-react/src/generated/api.schemas";

const DEPARTMENTS = ["Computer Science", "Electrical Engineering", "Mechanical Engineering", "Business", "Arts"];

export default function Teachers() {
  const { data, isLoading } = useTeachers();
  const createTeacher = useCreateTeacher();
  const updateTeacher = useUpdateTeacher();
  const deleteTeacher = useDeleteTeacher();

  const [search, setSearch] = useState("");
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingTeacher, setEditingTeacher] = useState<Teacher | null>(null);

  const [formData, setFormData] = useState<CreateTeacherRequest>({
    name: "", email: "", password: "", employeeId: "", department: DEPARTMENTS[0], specialization: "", phone: ""
  });

  const teachers = data?.teachers || [];
  const filteredTeachers = teachers.filter(t => 
    t.name.toLowerCase().includes(search.toLowerCase()) || 
    t.employeeId.toLowerCase().includes(search.toLowerCase())
  );

  const openAddModal = () => {
    setEditingTeacher(null);
    setFormData({ name: "", email: "", password: "", employeeId: "", department: DEPARTMENTS[0], specialization: "", phone: "" });
    setIsModalOpen(true);
  };

  const openEditModal = (teacher: Teacher) => {
    setEditingTeacher(teacher);
    setFormData({ 
      name: teacher.name, email: teacher.email, password: "", 
      employeeId: teacher.employeeId, department: teacher.department, 
      specialization: teacher.specialization || "", phone: teacher.phone || ""
    });
    setIsModalOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (editingTeacher) {
        const { password, ...updateData } = formData;
        const payload = password ? formData : updateData;
        await updateTeacher.mutateAsync({ id: editingTeacher.id, data: payload });
      } else {
        await createTeacher.mutateAsync(formData);
      }
      setIsModalOpen(false);
    } catch (err) {
      console.error(err);
    }
  };

  const handleDelete = async (id: number) => {
    if (confirm("Are you sure you want to delete this teacher?")) {
      await deleteTeacher.mutateAsync(id);
    }
  };

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
      <PageHeader 
        title="Faculty Roster" 
        description="Manage teaching staff and their assignments."
        action={
          <Button onClick={openAddModal} className="gap-2">
            <Plus size={18} /> Add Teacher
          </Button>
        }
      />

      <Card className="p-0 overflow-hidden">
        <div className="p-4 border-b border-white/5 bg-white/[0.02]">
          <div className="max-w-md relative">
            <Input 
              placeholder="Search by name or employee ID..." 
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              icon={<Search size={18} />}
              className="bg-black/50"
            />
          </div>
        </div>
        
        {isLoading ? (
          <div className="flex h-64 items-center justify-center">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : (
          <Table>
            <thead>
              <Tr>
                <Th>EMP ID</Th>
                <Th>Name</Th>
                <Th>Department</Th>
                <Th>Specialization</Th>
                <Th className="text-right">Actions</Th>
              </Tr>
            </thead>
            <tbody>
              {filteredTeachers.map(teacher => (
                <Tr key={teacher.id}>
                  <Td className="font-mono text-muted-foreground">{teacher.employeeId}</Td>
                  <Td>
                    <div className="font-medium text-white">{teacher.name}</div>
                    <div className="text-xs text-muted-foreground">{teacher.email}</div>
                  </Td>
                  <Td><Badge variant="default">{teacher.department}</Badge></Td>
                  <Td className="text-muted-foreground">{teacher.specialization || '-'}</Td>
                  <Td className="text-right space-x-2">
                    <Button variant="ghost" size="icon" onClick={() => openEditModal(teacher)}>
                      <Edit2 size={16} />
                    </Button>
                    <Button variant="ghost" size="icon" className="text-destructive hover:text-destructive hover:bg-destructive/10" onClick={() => handleDelete(teacher.id)}>
                      <Trash2 size={16} />
                    </Button>
                  </Td>
                </Tr>
              ))}
              {filteredTeachers.length === 0 && (
                <Tr>
                  <Td colSpan={5} className="text-center py-12 text-muted-foreground">
                    <div className="flex flex-col items-center gap-2">
                      <AlertCircle className="h-8 w-8 opacity-50" />
                      <p>No teachers found.</p>
                    </div>
                  </Td>
                </Tr>
              )}
            </tbody>
          </Table>
        )}
      </Card>

      <Modal 
        isOpen={isModalOpen} 
        onClose={() => setIsModalOpen(false)} 
        title={editingTeacher ? "Edit Teacher" : "Add New Teacher"}
      >
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label className="text-sm font-medium text-white/80">Full Name</label>
              <Input required value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} placeholder="Jane Smith" />
            </div>
            <div className="space-y-1.5">
              <label className="text-sm font-medium text-white/80">Employee ID</label>
              <Input required value={formData.employeeId} onChange={e => setFormData({...formData, employeeId: e.target.value})} placeholder="EMP-2024" />
            </div>
          </div>

          <div className="space-y-1.5">
            <label className="text-sm font-medium text-white/80">Email</label>
            <Input required type="email" value={formData.email} onChange={e => setFormData({...formData, email: e.target.value})} placeholder="jane@example.com" />
          </div>

          {!editingTeacher && (
            <div className="space-y-1.5">
              <label className="text-sm font-medium text-white/80">Password</label>
              <Input required type="password" value={formData.password} onChange={e => setFormData({...formData, password: e.target.value})} placeholder="Initial password" />
            </div>
          )}

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label className="text-sm font-medium text-white/80">Department</label>
              <Select value={formData.department} onChange={e => setFormData({...formData, department: e.target.value})}>
                {DEPARTMENTS.map(d => <option key={d} value={d} className="bg-background">{d}</option>)}
              </Select>
            </div>
            <div className="space-y-1.5">
              <label className="text-sm font-medium text-white/80">Specialization</label>
              <Input value={formData.specialization} onChange={e => setFormData({...formData, specialization: e.target.value})} placeholder="e.g. AI, Databases" />
            </div>
          </div>

          <div className="flex justify-end gap-3 mt-8">
            <Button type="button" variant="ghost" onClick={() => setIsModalOpen(false)}>Cancel</Button>
            <Button type="submit" isLoading={createTeacher.isPending || updateTeacher.isPending}>
              {editingTeacher ? "Save Changes" : "Create Teacher"}
            </Button>
          </div>
        </form>
      </Modal>
    </motion.div>
  );
}
