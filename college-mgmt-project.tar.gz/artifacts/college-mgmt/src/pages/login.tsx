import React, { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { Input, Button, Card } from "@/components/ui-elements";
import { Mail, Lock, ShieldAlert } from "lucide-react";
import { motion } from "framer-motion";

export default function Login() {
  const { login, isLoggingIn } = useAuth();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    if (!email || !password) {
      setError("Please enter email and password");
      return;
    }
    
    try {
      await login({ email, password });
    } catch (err: any) {
      setError(err.message || "Invalid credentials. Try admin@college.edu / admin123");
    }
  };

  return (
    <div className="min-h-screen w-full flex items-center justify-center relative overflow-hidden bg-background">
      {/* Dynamic Background */}
      <div className="absolute inset-0 z-0">
        <img 
          src={`${import.meta.env.BASE_URL}images/login-bg.png`} 
          alt="Abstract Background" 
          className="w-full h-full object-cover opacity-40 mix-blend-screen"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/80 to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-r from-background via-transparent to-background" />
      </div>

      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, ease: "easeOut" }}
        className="relative z-10 w-full max-w-md px-4"
      >
        <div className="text-center mb-10">
          <motion.div 
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ delay: 0.2, duration: 0.5 }}
            className="w-20 h-20 mx-auto bg-gradient-to-br from-primary to-primary/40 rounded-3xl flex items-center justify-center shadow-[0_0_40px_rgba(225,29,72,0.4)] mb-6 border border-white/10"
          >
            <span className="text-4xl font-display font-bold text-white">N</span>
          </motion.div>
          <h1 className="text-4xl font-display font-bold text-white tracking-tight mb-2">Nexus Portal</h1>
          <p className="text-muted-foreground text-lg">Sign in to your account</p>
        </div>

        <Card className="p-8 border-white/10 bg-black/40 backdrop-blur-2xl">
          <form onSubmit={handleSubmit} className="space-y-6">
            {error && (
              <motion.div 
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                className="bg-destructive/10 border border-destructive/20 text-destructive-foreground p-4 rounded-xl flex items-center gap-3 text-sm"
              >
                <ShieldAlert className="h-5 w-5 text-destructive shrink-0" />
                <p>{error}</p>
              </motion.div>
            )}

            <div className="space-y-4">
              <div className="space-y-2">
                <label className="text-sm font-medium text-white/80 ml-1">Email Address</label>
                <Input
                  type="email"
                  placeholder="admin@college.edu"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  icon={<Mail className="h-5 w-5" />}
                  className="bg-black/50 border-white/10 focus-visible:ring-primary/50"
                />
              </div>
              
              <div className="space-y-2">
                <div className="flex items-center justify-between ml-1">
                  <label className="text-sm font-medium text-white/80">Password</label>
                </div>
                <Input
                  type="password"
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  icon={<Lock className="h-5 w-5" />}
                  className="bg-black/50 border-white/10 focus-visible:ring-primary/50"
                />
              </div>
            </div>

            <Button 
              type="submit" 
              className="w-full h-12 text-base font-semibold shadow-primary/25 mt-2" 
              isLoading={isLoggingIn}
            >
              Authenticate
            </Button>
          </form>
        </Card>
        
        <p className="text-center mt-8 text-sm text-muted-foreground/60">
          Secure College Management System v1.0
        </p>
      </motion.div>
    </div>
  );
}
