import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { login as apiLogin, getMe as apiGetMe } from "@workspace/api-client-react";
import type { LoginRequest } from "@workspace/api-client-react/src/generated/api.schemas";
import { getAuthHeaders } from "@/lib/utils";
import { useLocation } from "wouter";

export const AUTH_QUERY_KEY = ["currentUser"];

export function useAuth() {
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();

  const { data: user, isLoading, error } = useQuery({
    queryKey: AUTH_QUERY_KEY,
    queryFn: async () => {
      if (!localStorage.getItem("cms_token")) return null;
      try {
        return await apiGetMe({ headers: getAuthHeaders() });
      } catch (e) {
        localStorage.removeItem("cms_token");
        return null;
      }
    },
    retry: false,
  });

  const loginMutation = useMutation({
    mutationFn: async (credentials: LoginRequest) => {
      return await apiLogin(credentials);
    },
    onSuccess: (data) => {
      localStorage.setItem("cms_token", data.token);
      queryClient.setQueryData(AUTH_QUERY_KEY, data.user);
      setLocation("/");
    },
  });

  const logout = () => {
    localStorage.removeItem("cms_token");
    queryClient.setQueryData(AUTH_QUERY_KEY, null);
    setLocation("/login");
  };

  return {
    user,
    isLoading,
    error,
    login: loginMutation.mutate,
    isLoggingIn: loginMutation.isPending,
    loginError: loginMutation.error,
    logout,
    isAuthenticated: !!user,
  };
}
