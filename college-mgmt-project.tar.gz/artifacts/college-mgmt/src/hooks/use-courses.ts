import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { 
  getCourses, 
  createCourse, 
  updateCourse, 
  deleteCourse 
} from "@workspace/api-client-react";
import type { CreateCourseRequest, UpdateCourseRequest } from "@workspace/api-client-react/src/generated/api.schemas";
import { getAuthHeaders } from "@/lib/utils";

const COURSES_KEY = ["courses"];

export function useCourses() {
  return useQuery({
    queryKey: COURSES_KEY,
    queryFn: () => getCourses({ headers: getAuthHeaders() }),
  });
}

export function useCreateCourse() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (data: CreateCourseRequest) => createCourse(data, { headers: getAuthHeaders() }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: COURSES_KEY }),
  });
}

export function useUpdateCourse() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ id, data }: { id: number; data: UpdateCourseRequest }) => 
      updateCourse(id, data, { headers: getAuthHeaders() }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: COURSES_KEY }),
  });
}

export function useDeleteCourse() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (id: number) => deleteCourse(id, { headers: getAuthHeaders() }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: COURSES_KEY }),
  });
}
