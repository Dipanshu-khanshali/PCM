import { Router } from "express";
import bcrypt from "bcryptjs";
import { db } from "@workspace/db";
import { usersTable, studentsTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { requireAuth } from "../middlewares/auth.js";

const router = Router();

router.get("/", requireAuth, async (_req, res) => {
  const students = await db.select().from(studentsTable).orderBy(studentsTable.createdAt);
  res.json({ students, total: students.length });
});

router.get("/:id", requireAuth, async (req, res) => {
  const [student] = await db.select().from(studentsTable).where(eq(studentsTable.id, Number(req.params["id"])));
  if (!student) {
    res.status(404).json({ message: "Student not found" });
    return;
  }
  res.json(student);
});

router.post("/", requireAuth, async (req, res) => {
  const { name, email, password, rollNumber, department, semester, phone, address } = req.body;
  if (!name || !email || !password || !rollNumber || !department || !semester) {
    res.status(400).json({ message: "Missing required fields" });
    return;
  }

  const hashedPassword = await bcrypt.hash(password, 10);
  const [user] = await db.insert(usersTable).values({ name, email, password: hashedPassword, role: "student" }).returning();

  const [student] = await db
    .insert(studentsTable)
    .values({ userId: user.id, name, email, rollNumber, department, semester: Number(semester), phone, address })
    .returning();

  res.status(201).json(student);
});

router.put("/:id", requireAuth, async (req, res) => {
  const { name, email, rollNumber, department, semester, phone, address } = req.body;
  const id = Number(req.params["id"]);
  const [existing] = await db.select().from(studentsTable).where(eq(studentsTable.id, id));
  if (!existing) {
    res.status(404).json({ message: "Student not found" });
    return;
  }

  const [updated] = await db
    .update(studentsTable)
    .set({ name, email, rollNumber, department, semester: semester ? Number(semester) : undefined, phone, address })
    .where(eq(studentsTable.id, id))
    .returning();

  if (updated.userId && (name || email)) {
    await db.update(usersTable).set({ name, email }).where(eq(usersTable.id, updated.userId));
  }

  res.json(updated);
});

router.delete("/:id", requireAuth, async (req, res) => {
  const id = Number(req.params["id"]);
  const [existing] = await db.select().from(studentsTable).where(eq(studentsTable.id, id));
  if (!existing) {
    res.status(404).json({ message: "Student not found" });
    return;
  }

  await db.delete(studentsTable).where(eq(studentsTable.id, id));
  if (existing.userId) {
    await db.delete(usersTable).where(eq(usersTable.id, existing.userId));
  }

  res.json({ message: "Student deleted successfully", success: true });
});

export default router;
