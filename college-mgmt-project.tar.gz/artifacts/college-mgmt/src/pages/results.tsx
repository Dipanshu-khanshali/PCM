import React, { useState } from "react";
import { useCourses } from "@/hooks/use-courses";
import { useStudents } from "@/hooks/use-students";
import { useResults, useAddResult, useUpdateResult } from "@/hooks/use-results";
import { PageHeader, Card, Table, Th, Tr, Td, Select, Input, Badge, Button, Modal } from "@/components/ui-elements";
import { Award, BookOpen, AlertCircle, Edit2, Check } from "lucide-react";
import { motion } from "framer-motion";
import type { Result, Student } from "@workspace/api-client-react/src/generated/api.schemas";

const EXAM_TYPES = ["midterm", "final", "assignment", "quiz"] as const;

export default function Results() {
  const [selectedCourse, setSelectedCourse] = useState<string>("");
  const [examType, setExamType] = useState<string>("midterm");
  
  const { data: coursesData } = useCourses();
  const { data: studentsData } = useStudents();
  const { data: resultsData } = useResults({
    courseId: selectedCourse ? parseInt(selectedCourse) : undefined
  });

  const addResult = useAddResult();
  const updateResult = useUpdateResult();

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedStudent, setSelectedStudent] = useState<Student | null>(null);
  const [marks, setMarks] = useState<number>(0);
  const [maxMarks, setMaxMarks] = useState<number>(100);

  const courses = coursesData?.courses || [];
  const students = studentsData?.students || [];
  const results = resultsData?.results || [];

  const getResultForStudent = (studentId: number) => {
    // Filter by both course and exam type context
    return results.find(r => r.studentId === studentId && r.examType === examType);
  };

  const openMarksModal = (student: Student) => {
    const existing = getResultForStudent(student.id);
    setSelectedStudent(student);
    setMarks(existing ? existing.marks : 0);
    setMaxMarks(existing ? existing.maxMarks : 100);
    setIsModalOpen(true);
  };

  const handleSaveMarks = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedStudent || !selectedCourse) return;

    const existing = getResultForStudent(selectedStudent.id);
    
    try {
      if (existing) {
        await updateResult.mutateAsync({
          id: existing.id,
          data: { marks, maxMarks, examType: examType as any }
        });
      } else {
        await addResult.mutateAsync({
          studentId: selectedStudent.id,
          courseId: parseInt(selectedCourse),
          marks,
          maxMarks,
          examType: examType as any,
          semester: selectedStudent.semester
        });
      }
      setIsModalOpen(false);
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
      <PageHeader 
        title="Grade Book" 
        description="Enter and manage student grades and exam results."
      />

      <Card className="p-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-2xl">
          <div className="space-y-2">
            <label className="text-sm font-medium text-white/80 flex items-center gap-2">
              <BookOpen size={16} className="text-primary" /> Course
            </label>
            <Select value={selectedCourse} onChange={(e) => setSelectedCourse(e.target.value)}>
              <option value="" className="bg-background">-- Select Course --</option>
              {courses.map(c => (
                <option key={c.id} value={c.id} className="bg-background">{c.code} - {c.name}</option>
              ))}
            </Select>
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium text-white/80 flex items-center gap-2">
              <Award size={16} className="text-primary" /> Exam Type
            </label>
            <Select value={examType} onChange={(e) => setExamType(e.target.value)}>
              {EXAM_TYPES.map(t => (
                <option key={t} value={t} className="bg-background capitalize">{t}</option>
              ))}
            </Select>
          </div>
        </div>
      </Card>

      {selectedCourse ? (
        <Card className="p-0 overflow-hidden">
          <div className="p-4 border-b border-white/5 bg-white/[0.02]">
            <h3 className="font-semibold text-white capitalize">{examType} Results</h3>
          </div>
          <Table>
            <thead>
              <Tr>
                <Th>Roll No</Th>
                <Th>Student Name</Th>
                <Th>Score</Th>
                <Th>Grade</Th>
                <Th className="text-right">Action</Th>
              </Tr>
            </thead>
            <tbody>
              {students.map(student => {
                const result = getResultForStudent(student.id);
                return (
                  <Tr key={student.id}>
                    <Td className="font-mono text-muted-foreground">{student.rollNumber}</Td>
                    <Td className="font-medium text-white">{student.name}</Td>
                    <Td>
                      {result ? (
                        <span className="font-mono text-primary font-bold">{result.marks} <span className="text-muted-foreground font-normal text-xs">/ {result.maxMarks}</span></span>
                      ) : (
                        <span className="text-muted-foreground italic text-sm">Not entered</span>
                      )}
                    </Td>
                    <Td>
                      {result ? (
                         <Badge variant={result.grade === 'F' ? 'danger' : result.grade === 'A' ? 'success' : 'warning'}>
                         {result.grade}
                       </Badge>
                      ) : '-'}
                    </Td>
                    <Td className="text-right">
                      <Button variant={result ? "outline" : "primary"} size="sm" onClick={() => openMarksModal(student)}>
                        {result ? <Edit2 size={14} className="mr-1.5" /> : <Plus size={14} className="mr-1.5" />}
                        {result ? "Edit" : "Enter"}
                      </Button>
                    </Td>
                  </Tr>
                );
              })}
            </tbody>
          </Table>
        </Card>
      ) : (
        <div className="flex flex-col items-center justify-center p-12 text-muted-foreground border border-dashed border-white/10 rounded-2xl bg-white/[0.01]">
          <BookOpen className="h-12 w-12 mb-4 opacity-20" />
          <p className="text-lg">Select a course to manage grades.</p>
        </div>
      )}

      <Modal 
        isOpen={isModalOpen} 
        onClose={() => setIsModalOpen(false)} 
        title={`Enter ${examType.charAt(0).toUpperCase() + examType.slice(1)} Marks`}
        maxWidth="max-w-sm"
      >
        {selectedStudent && (
          <form onSubmit={handleSaveMarks} className="space-y-6">
            <div className="p-4 bg-white/[0.02] rounded-xl border border-white/5 text-sm">
              <p className="text-muted-foreground">Student: <span className="text-white font-medium">{selectedStudent.name}</span></p>
              <p className="text-muted-foreground">Roll No: <span className="text-white font-medium">{selectedStudent.rollNumber}</span></p>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <label className="text-sm font-medium text-white/80">Marks Obtained</label>
                <Input 
                  required 
                  type="number" 
                  step="0.1"
                  min={0}
                  max={maxMarks}
                  value={marks} 
                  onChange={e => setMarks(parseFloat(e.target.value))} 
                />
              </div>
              <div className="space-y-1.5">
                <label className="text-sm font-medium text-white/80">Max Marks</label>
                <Input 
                  required 
                  type="number" 
                  min={1}
                  value={maxMarks} 
                  onChange={e => setMaxMarks(parseInt(e.target.value))} 
                />
              </div>
            </div>

            <Button type="submit" className="w-full" isLoading={addResult.isPending || updateResult.isPending}>
              Save Result
            </Button>
          </form>
        )}
      </Modal>
    </motion.div>
  );
}
