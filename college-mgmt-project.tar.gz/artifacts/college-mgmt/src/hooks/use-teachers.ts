import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { 
  getTeachers, 
  createTeacher, 
  updateTeacher, 
  deleteTeacher 
} from "@workspace/api-client-react";
import type { CreateTeacherRequest, UpdateTeacherRequest } from "@workspace/api-client-react/src/generated/api.schemas";
import { getAuthHeaders } from "@/lib/utils";

const TEACHERS_KEY = ["teachers"];

export function useTeachers() {
  return useQuery({
    queryKey: TEACHERS_KEY,
    queryFn: () => getTeachers({ headers: getAuthHeaders() }),
  });
}

export function useCreateTeacher() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (data: CreateTeacherRequest) => createTeacher(data, { headers: getAuthHeaders() }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: TEACHERS_KEY }),
  });
}

export function useUpdateTeacher() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ id, data }: { id: number; data: UpdateTeacherRequest }) => 
      updateTeacher(id, data, { headers: getAuthHeaders() }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: TEACHERS_KEY }),
  });
}

export function useDeleteTeacher() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (id: number) => deleteTeacher(id, { headers: getAuthHeaders() }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: TEACHERS_KEY }),
  });
}
