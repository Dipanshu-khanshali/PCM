import { pgTable, serial, integer, date, timestamp, pgEnum } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { studentsTable } from "./students";
import { coursesTable } from "./courses";
import { usersTable } from "./users";

export const attendanceStatusEnum = pgEnum("attendance_status", ["present", "absent", "late"]);

export const attendanceTable = pgTable("attendance", {
  id: serial("id").primaryKey(),
  studentId: integer("student_id").references(() => studentsTable.id, { onDelete: "cascade" }).notNull(),
  courseId: integer("course_id").references(() => coursesTable.id, { onDelete: "cascade" }).notNull(),
  date: date("date").notNull(),
  status: attendanceStatusEnum("status").notNull(),
  markedBy: integer("marked_by").references(() => usersTable.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertAttendanceSchema = createInsertSchema(attendanceTable).omit({ id: true, createdAt: true });
export type InsertAttendance = z.infer<typeof insertAttendanceSchema>;
export type Attendance = typeof attendanceTable.$inferSelect;
