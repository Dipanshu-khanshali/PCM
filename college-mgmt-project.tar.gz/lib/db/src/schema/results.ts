import { pgTable, serial, integer, real, text, timestamp, pgEnum } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { studentsTable } from "./students";
import { coursesTable } from "./courses";

export const examTypeEnum = pgEnum("exam_type", ["midterm", "final", "assignment", "quiz"]);

export const resultsTable = pgTable("results", {
  id: serial("id").primaryKey(),
  studentId: integer("student_id").references(() => studentsTable.id, { onDelete: "cascade" }).notNull(),
  courseId: integer("course_id").references(() => coursesTable.id, { onDelete: "cascade" }).notNull(),
  marks: real("marks").notNull(),
  maxMarks: real("max_marks").notNull().default(100),
  grade: text("grade").notNull(),
  percentage: real("percentage").notNull(),
  examType: examTypeEnum("exam_type").notNull(),
  semester: integer("semester"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertResultSchema = createInsertSchema(resultsTable).omit({ id: true, createdAt: true });
export type InsertResult = z.infer<typeof insertResultSchema>;
export type Result = typeof resultsTable.$inferSelect;
