import bcrypt from "bcryptjs";
import { db } from "@workspace/db";
import { usersTable, studentsTable, teachersTable, coursesTable } from "@workspace/db";
import { eq } from "drizzle-orm";

async function seed() {
  console.log("Seeding database...");

  const existingAdmin = await db.select().from(usersTable).where(eq(usersTable.email, "admin@college.edu"));
  if (existingAdmin.length === 0) {
    const hashedPassword = await bcrypt.hash("admin123", 10);
    await db.insert(usersTable).values({ name: "Admin", email: "admin@college.edu", password: hashedPassword, role: "admin" });
    console.log("Created admin user: admin@college.edu / admin123");
  } else {
    console.log("Admin user already exists");
  }

  const existingTeacher = await db.select().from(teachersTable).where(eq(teachersTable.email, "teacher@college.edu"));
  if (existingTeacher.length === 0) {
    const hashedPassword = await bcrypt.hash("teacher123", 10);
    const [teacherUser] = await db.insert(usersTable).values({ name: "Dr. Jane Smith", email: "teacher@college.edu", password: hashedPassword, role: "teacher" }).returning();
    await db.insert(teachersTable).values({ userId: teacherUser.id, name: "Dr. Jane Smith", email: "teacher@college.edu", employeeId: "EMP001", department: "Computer Science", specialization: "Algorithms" });
    console.log("Created teacher: teacher@college.edu / teacher123");
  }

  const existingStudent = await db.select().from(studentsTable).where(eq(studentsTable.email, "student@college.edu"));
  if (existingStudent.length === 0) {
    const hashedPassword = await bcrypt.hash("student123", 10);
    const [studentUser] = await db.insert(usersTable).values({ name: "John Doe", email: "student@college.edu", password: hashedPassword, role: "student" }).returning();
    await db.insert(studentsTable).values({ userId: studentUser.id, name: "John Doe", email: "student@college.edu", rollNumber: "CS2024001", department: "Computer Science", semester: 3 });
    console.log("Created student: student@college.edu / student123");
  }

  const existingCourse = await db.select().from(coursesTable).where(eq(coursesTable.code, "CS101"));
  if (existingCourse.length === 0) {
    const [teacher] = await db.select().from(teachersTable).where(eq(teachersTable.email, "teacher@college.edu"));
    await db.insert(coursesTable).values([
      { name: "Introduction to Computer Science", code: "CS101", credits: 3, teacherId: teacher?.id, department: "Computer Science", semester: 1, description: "Basics of CS" },
      { name: "Data Structures", code: "CS201", credits: 4, teacherId: teacher?.id, department: "Computer Science", semester: 3, description: "Arrays, Lists, Trees" },
      { name: "Database Management", code: "CS301", credits: 3, teacherId: teacher?.id, department: "Computer Science", semester: 5, description: "SQL and NoSQL databases" },
    ]);
    console.log("Created sample courses");
  }

  console.log("Seed complete!");
  process.exit(0);
}

seed().catch((err) => {
  console.error("Seed error:", err);
  process.exit(1);
});
