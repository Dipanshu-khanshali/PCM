import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { 
  getStudents, 
  createStudent, 
  updateStudent, 
  deleteStudent 
} from "@workspace/api-client-react";
import type { CreateStudentRequest, UpdateStudentRequest } from "@workspace/api-client-react/src/generated/api.schemas";
import { getAuthHeaders } from "@/lib/utils";

const STUDENTS_KEY = ["students"];

export function useStudents() {
  return useQuery({
    queryKey: STUDENTS_KEY,
    queryFn: () => getStudents({ headers: getAuthHeaders() }),
  });
}

export function useCreateStudent() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (data: CreateStudentRequest) => createStudent(data, { headers: getAuthHeaders() }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: STUDENTS_KEY }),
  });
}

export function useUpdateStudent() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ id, data }: { id: number; data: UpdateStudentRequest }) => 
      updateStudent(id, data, { headers: getAuthHeaders() }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: STUDENTS_KEY }),
  });
}

export function useDeleteStudent() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (id: number) => deleteStudent(id, { headers: getAuthHeaders() }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: STUDENTS_KEY }),
  });
}
