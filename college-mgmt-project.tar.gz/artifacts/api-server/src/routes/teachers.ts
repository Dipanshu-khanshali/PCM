import { Router } from "express";
import bcrypt from "bcryptjs";
import { db } from "@workspace/db";
import { usersTable, teachersTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { requireAuth } from "../middlewares/auth.js";

const router = Router();

router.get("/", requireAuth, async (_req, res) => {
  const teachers = await db.select().from(teachersTable).orderBy(teachersTable.createdAt);
  res.json({ teachers, total: teachers.length });
});

router.get("/:id", requireAuth, async (req, res) => {
  const [teacher] = await db.select().from(teachersTable).where(eq(teachersTable.id, Number(req.params["id"])));
  if (!teacher) {
    res.status(404).json({ message: "Teacher not found" });
    return;
  }
  res.json(teacher);
});

router.post("/", requireAuth, async (req, res) => {
  const { name, email, password, employeeId, department, specialization, phone } = req.body;
  if (!name || !email || !password || !employeeId || !department) {
    res.status(400).json({ message: "Missing required fields" });
    return;
  }

  const hashedPassword = await bcrypt.hash(password, 10);
  const [user] = await db.insert(usersTable).values({ name, email, password: hashedPassword, role: "teacher" }).returning();

  const [teacher] = await db
    .insert(teachersTable)
    .values({ userId: user.id, name, email, employeeId, department, specialization, phone })
    .returning();

  res.status(201).json(teacher);
});

router.put("/:id", requireAuth, async (req, res) => {
  const { name, email, employeeId, department, specialization, phone } = req.body;
  const id = Number(req.params["id"]);
  const [existing] = await db.select().from(teachersTable).where(eq(teachersTable.id, id));
  if (!existing) {
    res.status(404).json({ message: "Teacher not found" });
    return;
  }

  const [updated] = await db
    .update(teachersTable)
    .set({ name, email, employeeId, department, specialization, phone })
    .where(eq(teachersTable.id, id))
    .returning();

  if (existing.userId && (name || email)) {
    await db.update(usersTable).set({ name, email }).where(eq(usersTable.id, existing.userId));
  }

  res.json(updated);
});

router.delete("/:id", requireAuth, async (req, res) => {
  const id = Number(req.params["id"]);
  const [existing] = await db.select().from(teachersTable).where(eq(teachersTable.id, id));
  if (!existing) {
    res.status(404).json({ message: "Teacher not found" });
    return;
  }

  await db.delete(teachersTable).where(eq(teachersTable.id, id));
  if (existing.userId) {
    await db.delete(usersTable).where(eq(usersTable.id, existing.userId));
  }

  res.json({ message: "Teacher deleted successfully", success: true });
});

export default router;
