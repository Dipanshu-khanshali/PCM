import React from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { 
  LayoutDashboard, 
  Users, 
  GraduationCap, 
  BookOpen, 
  CalendarCheck, 
  Award, 
  LogOut,
  Menu,
  X,
  User as UserIcon
} from "lucide-react";
import { cn } from "@/lib/utils";
import { motion, AnimatePresence } from "framer-motion";

export function Layout({ children }: { children: React.ReactNode }) {
  const { user, logout } = useAuth();
  const [location] = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = React.useState(false);

  const navItems = [
    { label: "Dashboard", href: "/", icon: LayoutDashboard, roles: ["admin", "teacher", "student"] },
    { label: "Students", href: "/students", icon: Users, roles: ["admin", "teacher"] },
    { label: "Teachers", href: "/teachers", icon: GraduationCap, roles: ["admin"] },
    { label: "Courses", href: "/courses", icon: BookOpen, roles: ["admin", "teacher", "student"] },
    { label: "Attendance", href: "/attendance", icon: CalendarCheck, roles: ["admin", "teacher", "student"] },
    { label: "Results", href: "/results", icon: Award, roles: ["admin", "teacher", "student"] },
  ];

  const visibleNavItems = navItems.filter(item => user && item.roles.includes(user.role));

  const SidebarContent = () => (
    <>
      <div className="p-6 mb-4">
        <div className="flex items-center gap-3">
          <div className="h-10 w-10 rounded-xl bg-gradient-to-br from-primary to-primary/60 flex items-center justify-center shadow-lg shadow-primary/20">
            <span className="text-white font-display font-bold text-xl">C</span>
          </div>
          <div>
            <h2 className="font-display font-bold text-lg leading-tight tracking-tight text-white">Nexus</h2>
            <p className="text-xs text-muted-foreground uppercase tracking-wider">College System</p>
          </div>
        </div>
      </div>

      <nav className="flex-1 px-4 space-y-1.5 overflow-y-auto">
        {visibleNavItems.map((item) => {
          const isActive = location === item.href;
          return (
            <Link key={item.href} href={item.href} onClick={() => setIsMobileMenuOpen(false)}>
              <span
                className={cn(
                  "flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 cursor-pointer group relative overflow-hidden",
                  isActive 
                    ? "text-white bg-white/5 font-medium" 
                    : "text-muted-foreground hover:text-white hover:bg-white/[0.02]"
                )}
              >
                {isActive && (
                  <motion.div 
                    layoutId="active-nav"
                    className="absolute left-0 top-1/2 -translate-y-1/2 w-1 h-8 bg-primary rounded-r-full shadow-[0_0_10px_rgba(225,29,72,0.8)]"
                  />
                )}
                <item.icon className={cn("h-5 w-5 transition-transform", isActive ? "text-primary scale-110" : "group-hover:text-white")} />
                {item.label}
              </span>
            </Link>
          );
        })}
      </nav>

      <div className="p-4 mt-auto">
        <div className="p-4 rounded-2xl bg-white/5 border border-white/5 backdrop-blur-md mb-4 flex items-center gap-3">
          <div className="h-10 w-10 rounded-full bg-secondary flex items-center justify-center border border-white/10">
            <UserIcon className="h-5 w-5 text-muted-foreground" />
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium text-white truncate">{user?.name}</p>
            <p className="text-xs text-primary capitalize tracking-wider font-medium">{user?.role}</p>
          </div>
        </div>
        <button
          onClick={() => {
            setIsMobileMenuOpen(false);
            logout();
          }}
          className="flex w-full items-center gap-3 px-4 py-3 text-muted-foreground hover:text-destructive hover:bg-destructive/10 rounded-xl transition-colors"
        >
          <LogOut className="h-5 w-5" />
          <span className="font-medium">Sign Out</span>
        </button>
      </div>
    </>
  );

  return (
    <div className="flex h-screen bg-background overflow-hidden selection:bg-primary/30">
      {/* Desktop Sidebar */}
      <aside className="hidden md:flex w-72 flex-col bg-[#0a0a0c] border-r border-white/5 relative z-20 shadow-2xl shadow-black">
        <SidebarContent />
      </aside>

      {/* Mobile Sidebar Overlay */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsMobileMenuOpen(false)}
              className="fixed inset-0 bg-black/80 backdrop-blur-sm z-40 md:hidden"
            />
            <motion.aside
              initial={{ x: "-100%" }}
              animate={{ x: 0 }}
              exit={{ x: "-100%" }}
              transition={{ type: "spring", damping: 25, stiffness: 200 }}
              className="fixed inset-y-0 left-0 w-72 bg-[#0a0a0c] border-r border-white/5 z-50 flex flex-col md:hidden shadow-2xl shadow-black"
            >
              <SidebarContent />
            </motion.aside>
          </>
        )}
      </AnimatePresence>

      <main className="flex-1 flex flex-col min-w-0 relative">
        {/* Subtle top glow */}
        <div className="absolute top-0 left-0 right-0 h-96 bg-primary/5 blur-[120px] rounded-full pointer-events-none -translate-y-1/2" />
        
        {/* Mobile Header */}
        <header className="md:hidden flex items-center justify-between p-4 border-b border-white/5 bg-background/80 backdrop-blur-md sticky top-0 z-30">
          <div className="flex items-center gap-3">
            <div className="h-8 w-8 rounded-lg bg-primary flex items-center justify-center">
              <span className="text-white font-display font-bold">N</span>
            </div>
            <span className="font-display font-bold text-white">Nexus</span>
          </div>
          <button 
            onClick={() => setIsMobileMenuOpen(true)}
            className="p-2 -mr-2 text-white hover:bg-white/10 rounded-lg"
          >
            <Menu className="h-6 w-6" />
          </button>
        </header>

        <div className="flex-1 overflow-y-auto p-4 md:p-8 lg:p-10 relative z-10">
          <div className="max-w-7xl mx-auto">
            {children}
          </div>
        </div>
      </main>
    </div>
  );
}
