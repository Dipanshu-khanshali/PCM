import jwt from "jsonwebtoken";

const JWT_SECRET = process.env["JWT_SECRET"] || process.env["SESSION_SECRET"] || "college-mgmt-secret-key";

export interface JwtPayload {
  id: number;
  email: string;
  role: string;
  name: string;
}

export function signToken(payload: JwtPayload): string {
  return jwt.sign(payload, JWT_SECRET, { expiresIn: "7d" });
}

export function verifyToken(token: string): JwtPayload {
  return jwt.verify(token, JWT_SECRET) as JwtPayload;
}
