import { Router } from "express";
import { db } from "@workspace/db";
import { coursesTable, teachersTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { requireAuth } from "../middlewares/auth.js";

const router = Router();

router.get("/", requireAuth, async (_req, res) => {
  const coursesRaw = await db
    .select({
      id: coursesTable.id,
      name: coursesTable.name,
      code: coursesTable.code,
      description: coursesTable.description,
      credits: coursesTable.credits,
      teacherId: coursesTable.teacherId,
      teacherName: teachersTable.name,
      department: coursesTable.department,
      semester: coursesTable.semester,
      createdAt: coursesTable.createdAt,
    })
    .from(coursesTable)
    .leftJoin(teachersTable, eq(coursesTable.teacherId, teachersTable.id))
    .orderBy(coursesTable.createdAt);

  res.json({ courses: coursesRaw, total: coursesRaw.length });
});

router.post("/", requireAuth, async (req, res) => {
  const { name, code, description, credits, teacherId, department, semester } = req.body;
  if (!name || !code || !department || !semester) {
    res.status(400).json({ message: "Missing required fields" });
    return;
  }

  const [course] = await db
    .insert(coursesTable)
    .values({ name, code, description, credits: credits ?? 3, teacherId: teacherId || null, department, semester: Number(semester) })
    .returning();

  res.status(201).json(course);
});

router.put("/:id", requireAuth, async (req, res) => {
  const id = Number(req.params["id"]);
  const { name, code, description, credits, teacherId, department, semester } = req.body;

  const [updated] = await db
    .update(coursesTable)
    .set({ name, code, description, credits, teacherId: teacherId || null, department, semester: semester ? Number(semester) : undefined })
    .where(eq(coursesTable.id, id))
    .returning();

  if (!updated) {
    res.status(404).json({ message: "Course not found" });
    return;
  }

  res.json(updated);
});

router.delete("/:id", requireAuth, async (req, res) => {
  const id = Number(req.params["id"]);
  const [deleted] = await db.delete(coursesTable).where(eq(coursesTable.id, id)).returning();
  if (!deleted) {
    res.status(404).json({ message: "Course not found" });
    return;
  }
  res.json({ message: "Course deleted successfully", success: true });
});

export default router;
