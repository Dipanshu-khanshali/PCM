import { Router, type IRouter } from "express";
import healthRouter from "./health";
import authRouter from "./auth.js";
import studentsRouter from "./students.js";
import teachersRouter from "./teachers.js";
import coursesRouter from "./courses.js";
import attendanceRouter from "./attendance.js";
import resultsRouter from "./results.js";
import uploadRouter from "./upload.js";
import statsRouter from "./stats.js";

const router: IRouter = Router();

router.use(healthRouter);
router.use("/auth", authRouter);
router.use("/students", studentsRouter);
router.use("/teachers", teachersRouter);
router.use("/courses", coursesRouter);
router.use("/attendance", attendanceRouter);
router.use("/results", resultsRouter);
router.use("/upload", uploadRouter);
router.use("/stats", statsRouter);

export default router;
