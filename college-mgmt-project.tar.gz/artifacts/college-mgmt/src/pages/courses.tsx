import React, { useState } from "react";
import { useCourses, useCreateCourse, useUpdateCourse, useDeleteCourse } from "@/hooks/use-courses";
import { useTeachers } from "@/hooks/use-teachers";
import { PageHeader, Card, Table, Th, Tr, Td, Button, Input, Select, Modal, Badge } from "@/components/ui-elements";
import { Plus, Search, Edit2, Trash2, Loader2, AlertCircle } from "lucide-react";
import { motion } from "framer-motion";
import type { Course, CreateCourseRequest } from "@workspace/api-client-react/src/generated/api.schemas";

const DEPARTMENTS = ["Computer Science", "Electrical Engineering", "Mechanical Engineering", "Business", "Arts"];

export default function Courses() {
  const { data: coursesData, isLoading: loadingCourses } = useCourses();
  const { data: teachersData } = useTeachers();
  const createCourse = useCreateCourse();
  const updateCourse = useUpdateCourse();
  const deleteCourse = useDeleteCourse();

  const [search, setSearch] = useState("");
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingCourse, setEditingCourse] = useState<Course | null>(null);

  const [formData, setFormData] = useState<CreateCourseRequest>({
    name: "", code: "", description: "", credits: 3, teacherId: undefined, department: DEPARTMENTS[0], semester: 1
  });

  const courses = coursesData?.courses || [];
  const teachers = teachersData?.teachers || [];
  
  const filteredCourses = courses.filter(c => 
    c.name.toLowerCase().includes(search.toLowerCase()) || 
    c.code.toLowerCase().includes(search.toLowerCase())
  );

  const openAddModal = () => {
    setEditingCourse(null);
    setFormData({ name: "", code: "", description: "", credits: 3, teacherId: undefined, department: DEPARTMENTS[0], semester: 1 });
    setIsModalOpen(true);
  };

  const openEditModal = (course: Course) => {
    setEditingCourse(course);
    setFormData({ 
      name: course.name, code: course.code, description: course.description || "", 
      credits: course.credits, teacherId: course.teacherId, department: course.department, semester: course.semester
    });
    setIsModalOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (editingCourse) {
        await updateCourse.mutateAsync({ id: editingCourse.id, data: formData });
      } else {
        await createCourse.mutateAsync(formData);
      }
      setIsModalOpen(false);
    } catch (err) {
      console.error(err);
    }
  };

  const handleDelete = async (id: number) => {
    if (confirm("Are you sure you want to delete this course?")) {
      await deleteCourse.mutateAsync(id);
    }
  };

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
      <PageHeader 
        title="Course Catalog" 
        description="Manage curriculum, credits, and teacher assignments."
        action={
          <Button onClick={openAddModal} className="gap-2">
            <Plus size={18} /> Add Course
          </Button>
        }
      />

      <Card className="p-0 overflow-hidden">
        <div className="p-4 border-b border-white/5 bg-white/[0.02]">
          <div className="max-w-md relative">
            <Input 
              placeholder="Search by name or code..." 
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              icon={<Search size={18} />}
              className="bg-black/50"
            />
          </div>
        </div>
        
        {loadingCourses ? (
          <div className="flex h-64 items-center justify-center">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : (
          <Table>
            <thead>
              <Tr>
                <Th>Code</Th>
                <Th>Course Name</Th>
                <Th>Credits</Th>
                <Th>Department / Sem</Th>
                <Th>Instructor</Th>
                <Th className="text-right">Actions</Th>
              </Tr>
            </thead>
            <tbody>
              {filteredCourses.map(course => (
                <Tr key={course.id}>
                  <Td className="font-mono text-primary font-bold">{course.code}</Td>
                  <Td className="font-medium text-white">{course.name}</Td>
                  <Td>{course.credits}</Td>
                  <Td>
                    <div className="flex items-center gap-2">
                      <Badge>{course.department}</Badge>
                      <span className="text-xs text-muted-foreground">Sem {course.semester}</span>
                    </div>
                  </Td>
                  <Td className="text-muted-foreground">{course.teacherName || 'Unassigned'}</Td>
                  <Td className="text-right space-x-2">
                    <Button variant="ghost" size="icon" onClick={() => openEditModal(course)}>
                      <Edit2 size={16} />
                    </Button>
                    <Button variant="ghost" size="icon" className="text-destructive hover:text-destructive hover:bg-destructive/10" onClick={() => handleDelete(course.id)}>
                      <Trash2 size={16} />
                    </Button>
                  </Td>
                </Tr>
              ))}
              {filteredCourses.length === 0 && (
                <Tr>
                  <Td colSpan={6} className="text-center py-12 text-muted-foreground">
                    <div className="flex flex-col items-center gap-2">
                      <AlertCircle className="h-8 w-8 opacity-50" />
                      <p>No courses found.</p>
                    </div>
                  </Td>
                </Tr>
              )}
            </tbody>
          </Table>
        )}
      </Card>

      <Modal 
        isOpen={isModalOpen} 
        onClose={() => setIsModalOpen(false)} 
        title={editingCourse ? "Edit Course" : "Add New Course"}
      >
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-3 gap-4">
            <div className="space-y-1.5 col-span-2">
              <label className="text-sm font-medium text-white/80">Course Name</label>
              <Input required value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} placeholder="Intro to Programming" />
            </div>
            <div className="space-y-1.5">
              <label className="text-sm font-medium text-white/80">Code</label>
              <Input required value={formData.code} onChange={e => setFormData({...formData, code: e.target.value})} placeholder="CS101" />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label className="text-sm font-medium text-white/80">Department</label>
              <Select value={formData.department} onChange={e => setFormData({...formData, department: e.target.value})}>
                {DEPARTMENTS.map(d => <option key={d} value={d} className="bg-background">{d}</option>)}
              </Select>
            </div>
            <div className="space-y-1.5">
              <label className="text-sm font-medium text-white/80">Instructor</label>
              <Select 
                value={formData.teacherId || ""} 
                onChange={e => setFormData({...formData, teacherId: e.target.value ? parseInt(e.target.value) : undefined})}
              >
                <option value="" className="bg-background">Unassigned</option>
                {teachers.map(t => <option key={t.id} value={t.id} className="bg-background">{t.name}</option>)}
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label className="text-sm font-medium text-white/80">Credits</label>
              <Input required type="number" min={1} max={6} value={formData.credits} onChange={e => setFormData({...formData, credits: parseInt(e.target.value)})} />
            </div>
            <div className="space-y-1.5">
              <label className="text-sm font-medium text-white/80">Semester</label>
              <Input required type="number" min={1} max={8} value={formData.semester} onChange={e => setFormData({...formData, semester: parseInt(e.target.value)})} />
            </div>
          </div>

          <div className="space-y-1.5">
            <label className="text-sm font-medium text-white/80">Description</label>
            <textarea 
              className="w-full h-24 rounded-xl border border-border bg-background/50 px-4 py-2 text-sm text-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-primary focus-visible:border-primary resize-none"
              value={formData.description}
              onChange={e => setFormData({...formData, description: e.target.value})}
              placeholder="Course overview..."
            />
          </div>

          <div className="flex justify-end gap-3 mt-8">
            <Button type="button" variant="ghost" onClick={() => setIsModalOpen(false)}>Cancel</Button>
            <Button type="submit" isLoading={createCourse.isPending || updateCourse.isPending}>
              {editingCourse ? "Save Changes" : "Create Course"}
            </Button>
          </div>
        </form>
      </Modal>
    </motion.div>
  );
}
