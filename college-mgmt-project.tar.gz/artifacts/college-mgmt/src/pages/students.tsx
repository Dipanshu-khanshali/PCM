import React, { useState } from "react";
import { useStudents, useCreateStudent, useUpdateStudent, useDeleteStudent } from "@/hooks/use-students";
import { PageHeader, Card, Table, Th, Tr, Td, Button, Input, Select, Modal, Badge } from "@/components/ui-elements";
import { Plus, Search, Edit2, Trash2, Loader2, AlertCircle } from "lucide-react";
import { motion } from "framer-motion";
import type { Student, CreateStudentRequest } from "@workspace/api-client-react/src/generated/api.schemas";

const DEPARTMENTS = ["Computer Science", "Electrical Engineering", "Mechanical Engineering", "Business", "Arts"];

export default function Students() {
  const { data, isLoading } = useStudents();
  const createStudent = useCreateStudent();
  const updateStudent = useUpdateStudent();
  const deleteStudent = useDeleteStudent();

  const [search, setSearch] = useState("");
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingStudent, setEditingStudent] = useState<Student | null>(null);

  // Form State
  const [formData, setFormData] = useState<CreateStudentRequest>({
    name: "", email: "", password: "", rollNumber: "", department: DEPARTMENTS[0], semester: 1, phone: "", address: ""
  });

  const students = data?.students || [];
  const filteredStudents = students.filter(s => 
    s.name.toLowerCase().includes(search.toLowerCase()) || 
    s.rollNumber.toLowerCase().includes(search.toLowerCase())
  );

  const openAddModal = () => {
    setEditingStudent(null);
    setFormData({ name: "", email: "", password: "", rollNumber: "", department: DEPARTMENTS[0], semester: 1, phone: "", address: "" });
    setIsModalOpen(true);
  };

  const openEditModal = (student: Student) => {
    setEditingStudent(student);
    setFormData({ 
      name: student.name, email: student.email, password: "", // password omitted for edit unless changing
      rollNumber: student.rollNumber, department: student.department, 
      semester: student.semester, phone: student.phone || "", address: student.address || ""
    });
    setIsModalOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (editingStudent) {
        // Omitting password if empty during edit
        const { password, ...updateData } = formData;
        const payload = password ? formData : updateData;
        await updateStudent.mutateAsync({ id: editingStudent.id, data: payload });
      } else {
        await createStudent.mutateAsync(formData);
      }
      setIsModalOpen(false);
    } catch (err) {
      console.error(err);
    }
  };

  const handleDelete = async (id: number) => {
    if (confirm("Are you sure you want to delete this student?")) {
      await deleteStudent.mutateAsync(id);
    }
  };

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
      <PageHeader 
        title="Student Directory" 
        description="Manage enrolled students and their profiles."
        action={
          <Button onClick={openAddModal} className="gap-2">
            <Plus size={18} /> Add Student
          </Button>
        }
      />

      <Card className="p-0 overflow-hidden">
        <div className="p-4 border-b border-white/5 bg-white/[0.02]">
          <div className="max-w-md relative">
            <Input 
              placeholder="Search by name or roll number..." 
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              icon={<Search size={18} />}
              className="bg-black/50"
            />
          </div>
        </div>
        
        {isLoading ? (
          <div className="flex h-64 items-center justify-center">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : (
          <Table>
            <thead>
              <Tr>
                <Th>Roll No</Th>
                <Th>Name</Th>
                <Th>Department</Th>
                <Th>Semester</Th>
                <Th className="text-right">Actions</Th>
              </Tr>
            </thead>
            <tbody>
              {filteredStudents.map(student => (
                <Tr key={student.id}>
                  <Td className="font-mono text-muted-foreground">{student.rollNumber}</Td>
                  <Td>
                    <div className="font-medium text-white">{student.name}</div>
                    <div className="text-xs text-muted-foreground">{student.email}</div>
                  </Td>
                  <Td><Badge>{student.department}</Badge></Td>
                  <Td>Semester {student.semester}</Td>
                  <Td className="text-right space-x-2">
                    <Button variant="ghost" size="icon" onClick={() => openEditModal(student)}>
                      <Edit2 size={16} />
                    </Button>
                    <Button variant="ghost" size="icon" className="text-destructive hover:text-destructive hover:bg-destructive/10" onClick={() => handleDelete(student.id)}>
                      <Trash2 size={16} />
                    </Button>
                  </Td>
                </Tr>
              ))}
              {filteredStudents.length === 0 && (
                <Tr>
                  <Td colSpan={5} className="text-center py-12 text-muted-foreground">
                    <div className="flex flex-col items-center gap-2">
                      <AlertCircle className="h-8 w-8 opacity-50" />
                      <p>No students found.</p>
                    </div>
                  </Td>
                </Tr>
              )}
            </tbody>
          </Table>
        )}
      </Card>

      <Modal 
        isOpen={isModalOpen} 
        onClose={() => setIsModalOpen(false)} 
        title={editingStudent ? "Edit Student" : "Add New Student"}
      >
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label className="text-sm font-medium text-white/80">Full Name</label>
              <Input required value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} placeholder="John Doe" />
            </div>
            <div className="space-y-1.5">
              <label className="text-sm font-medium text-white/80">Roll Number</label>
              <Input required value={formData.rollNumber} onChange={e => setFormData({...formData, rollNumber: e.target.value})} placeholder="CS-2024-001" />
            </div>
          </div>

          <div className="space-y-1.5">
            <label className="text-sm font-medium text-white/80">Email</label>
            <Input required type="email" value={formData.email} onChange={e => setFormData({...formData, email: e.target.value})} placeholder="john@example.com" />
          </div>

          {!editingStudent && (
            <div className="space-y-1.5">
              <label className="text-sm font-medium text-white/80">Password</label>
              <Input required type="password" value={formData.password} onChange={e => setFormData({...formData, password: e.target.value})} placeholder="Initial password" />
            </div>
          )}

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label className="text-sm font-medium text-white/80">Department</label>
              <Select value={formData.department} onChange={e => setFormData({...formData, department: e.target.value})}>
                {DEPARTMENTS.map(d => <option key={d} value={d} className="bg-background">{d}</option>)}
              </Select>
            </div>
            <div className="space-y-1.5">
              <label className="text-sm font-medium text-white/80">Semester</label>
              <Input required type="number" min={1} max={8} value={formData.semester} onChange={e => setFormData({...formData, semester: parseInt(e.target.value)})} />
            </div>
          </div>

          <div className="space-y-1.5">
            <label className="text-sm font-medium text-white/80">Phone (Optional)</label>
            <Input value={formData.phone} onChange={e => setFormData({...formData, phone: e.target.value})} placeholder="+1 234 567 890" />
          </div>

          <div className="flex justify-end gap-3 mt-8">
            <Button type="button" variant="ghost" onClick={() => setIsModalOpen(false)}>Cancel</Button>
            <Button type="submit" isLoading={createStudent.isPending || updateStudent.isPending}>
              {editingStudent ? "Save Changes" : "Create Student"}
            </Button>
          </div>
        </form>
      </Modal>
    </motion.div>
  );
}
