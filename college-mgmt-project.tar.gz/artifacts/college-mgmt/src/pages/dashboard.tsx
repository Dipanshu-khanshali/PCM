import React from "react";
import { useDashboardStats } from "@/hooks/use-dashboard";
import { PageHeader, Card, Table, Th, Tr, Td, Badge } from "@/components/ui-elements";
import { Users, GraduationCap, BookOpen, CalendarCheck, TrendingUp, Loader2 } from "lucide-react";
import { motion } from "framer-motion";
import { formatDate } from "@/lib/utils";

export default function Dashboard() {
  const { data: stats, isLoading, error } = useDashboardStats();

  if (isLoading) {
    return (
      <div className="flex h-[50vh] items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (error || !stats) {
    return (
      <div className="p-8 text-center bg-destructive/10 border border-destructive/20 rounded-2xl">
        <p className="text-destructive-foreground font-medium">Failed to load dashboard statistics.</p>
      </div>
    );
  }

  const statCards = [
    { label: "Total Students", value: stats.totalStudents, icon: Users, color: "text-blue-400", bg: "bg-blue-400/10", border: "border-blue-400/20" },
    { label: "Total Teachers", value: stats.totalTeachers, icon: GraduationCap, color: "text-purple-400", bg: "bg-purple-400/10", border: "border-purple-400/20" },
    { label: "Active Courses", value: stats.totalCourses, icon: BookOpen, color: "text-amber-400", bg: "bg-amber-400/10", border: "border-amber-400/20" },
    { label: "Attendance Rate", value: `${stats.totalAttendance || 0}%`, icon: CalendarCheck, color: "text-emerald-400", bg: "bg-emerald-400/10", border: "border-emerald-400/20" },
  ];

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-8">
      <PageHeader 
        title="Overview" 
        description="Welcome back. Here's what's happening today." 
      />

      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
        {statCards.map((stat, i) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
          >
            <Card className="flex items-center gap-5 p-6 hover:-translate-y-1 transition-transform duration-300">
              <div className={`h-14 w-14 rounded-2xl flex items-center justify-center border ${stat.bg} ${stat.border}`}>
                <stat.icon className={`h-7 w-7 ${stat.color}`} />
              </div>
              <div>
                <p className="text-sm font-medium text-muted-foreground mb-1">{stat.label}</p>
                <h3 className="text-3xl font-display font-bold text-white tracking-tight">{stat.value}</h3>
              </div>
            </Card>
          </motion.div>
        ))}
      </div>

      <div className="grid lg:grid-cols-2 gap-8">
        {/* Recent Students */}
        <Card className="p-0 overflow-hidden flex flex-col">
          <div className="p-6 border-b border-white/5 flex items-center justify-between">
            <h3 className="text-lg font-display font-semibold text-white">Recent Enrollments</h3>
            <Badge variant="default">{stats.recentStudents?.length || 0} New</Badge>
          </div>
          <div className="flex-1 overflow-auto">
            <Table>
              <thead>
                <Tr>
                  <Th>Name</Th>
                  <Th>Roll No</Th>
                  <Th>Department</Th>
                </Tr>
              </thead>
              <tbody>
                {stats.recentStudents?.map(student => (
                  <Tr key={student.id}>
                    <Td className="font-medium text-white">{student.name}</Td>
                    <Td className="text-muted-foreground">{student.rollNumber}</Td>
                    <Td>
                      <Badge variant="default">{student.department}</Badge>
                    </Td>
                  </Tr>
                ))}
                {!stats.recentStudents?.length && (
                  <Tr>
                    <Td colSpan={3} className="text-center text-muted-foreground py-8">No recent students found.</Td>
                  </Tr>
                )}
              </tbody>
            </Table>
          </div>
        </Card>

        {/* Recent Results */}
        <Card className="p-0 overflow-hidden flex flex-col">
          <div className="p-6 border-b border-white/5 flex items-center justify-between">
            <h3 className="text-lg font-display font-semibold text-white">Latest Results</h3>
            <TrendingUp className="h-5 w-5 text-primary" />
          </div>
          <div className="flex-1 overflow-auto">
            <Table>
              <thead>
                <Tr>
                  <Th>Student</Th>
                  <Th>Course</Th>
                  <Th>Grade</Th>
                  <Th>Date</Th>
                </Tr>
              </thead>
              <tbody>
                {stats.recentResults?.map(result => (
                  <Tr key={result.id}>
                    <Td className="font-medium text-white">{result.studentName || `ID: ${result.studentId}`}</Td>
                    <Td className="text-muted-foreground">{result.courseName || `ID: ${result.courseId}`}</Td>
                    <Td>
                      <Badge variant={result.grade === 'F' ? 'danger' : result.grade === 'A' ? 'success' : 'warning'}>
                        {result.grade}
                      </Badge>
                    </Td>
                    <Td className="text-muted-foreground">{formatDate(result.createdAt)}</Td>
                  </Tr>
                ))}
                {!stats.recentResults?.length && (
                  <Tr>
                    <Td colSpan={4} className="text-center text-muted-foreground py-8">No recent results found.</Td>
                  </Tr>
                )}
              </tbody>
            </Table>
          </div>
        </Card>
      </div>
    </motion.div>
  );
}
