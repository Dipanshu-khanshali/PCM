import { Router } from "express";
import { db } from "@workspace/db";
import { attendanceTable, studentsTable, coursesTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import { requireAuth, type AuthRequest } from "../middlewares/auth.js";

const router = Router();

router.get("/", requireAuth, async (req, res) => {
  const { studentId, courseId, date } = req.query;

  const records = await db
    .select({
      id: attendanceTable.id,
      studentId: attendanceTable.studentId,
      studentName: studentsTable.name,
      courseId: attendanceTable.courseId,
      courseName: coursesTable.name,
      date: attendanceTable.date,
      status: attendanceTable.status,
      markedBy: attendanceTable.markedBy,
      createdAt: attendanceTable.createdAt,
    })
    .from(attendanceTable)
    .leftJoin(studentsTable, eq(attendanceTable.studentId, studentsTable.id))
    .leftJoin(coursesTable, eq(attendanceTable.courseId, coursesTable.id))
    .where(
      and(
        studentId ? eq(attendanceTable.studentId, Number(studentId)) : undefined,
        courseId ? eq(attendanceTable.courseId, Number(courseId)) : undefined,
        date ? eq(attendanceTable.date, String(date)) : undefined,
      )
    )
    .orderBy(attendanceTable.date);

  res.json({ records, total: records.length });
});

router.post("/", requireAuth, async (req: AuthRequest, res) => {
  const { studentId, courseId, date, status } = req.body;
  if (!studentId || !courseId || !date || !status) {
    res.status(400).json({ message: "Missing required fields" });
    return;
  }

  const [record] = await db
    .insert(attendanceTable)
    .values({ studentId: Number(studentId), courseId: Number(courseId), date, status, markedBy: req.user?.id })
    .returning();

  res.status(201).json(record);
});

export default router;
