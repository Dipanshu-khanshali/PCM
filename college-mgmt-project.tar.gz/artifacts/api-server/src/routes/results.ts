import { Router } from "express";
import { db } from "@workspace/db";
import { resultsTable, studentsTable, coursesTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import { requireAuth } from "../middlewares/auth.js";

function calculateGrade(percentage: number): string {
  if (percentage >= 90) return "A+";
  if (percentage >= 80) return "A";
  if (percentage >= 70) return "B";
  if (percentage >= 60) return "C";
  if (percentage >= 50) return "D";
  return "F";
}

const router = Router();

router.get("/", requireAuth, async (req, res) => {
  const { studentId, courseId } = req.query;

  const results = await db
    .select({
      id: resultsTable.id,
      studentId: resultsTable.studentId,
      studentName: studentsTable.name,
      courseId: resultsTable.courseId,
      courseName: coursesTable.name,
      marks: resultsTable.marks,
      maxMarks: resultsTable.maxMarks,
      grade: resultsTable.grade,
      percentage: resultsTable.percentage,
      examType: resultsTable.examType,
      semester: resultsTable.semester,
      createdAt: resultsTable.createdAt,
    })
    .from(resultsTable)
    .leftJoin(studentsTable, eq(resultsTable.studentId, studentsTable.id))
    .leftJoin(coursesTable, eq(resultsTable.courseId, coursesTable.id))
    .where(
      and(
        studentId ? eq(resultsTable.studentId, Number(studentId)) : undefined,
        courseId ? eq(resultsTable.courseId, Number(courseId)) : undefined,
      )
    )
    .orderBy(resultsTable.createdAt);

  res.json({ results, total: results.length });
});

router.post("/", requireAuth, async (req, res) => {
  const { studentId, courseId, marks, maxMarks, examType, semester } = req.body;
  if (studentId == null || courseId == null || marks == null || maxMarks == null || !examType) {
    res.status(400).json({ message: "Missing required fields" });
    return;
  }

  const percentage = (Number(marks) / Number(maxMarks)) * 100;
  const grade = calculateGrade(percentage);

  const [result] = await db
    .insert(resultsTable)
    .values({
      studentId: Number(studentId),
      courseId: Number(courseId),
      marks: Number(marks),
      maxMarks: Number(maxMarks),
      grade,
      percentage,
      examType,
      semester: semester ? Number(semester) : null,
    })
    .returning();

  res.status(201).json(result);
});

router.put("/:id", requireAuth, async (req, res) => {
  const id = Number(req.params["id"]);
  const { marks, maxMarks, examType } = req.body;

  let updateData: Record<string, unknown> = { examType };
  if (marks != null && maxMarks != null) {
    const percentage = (Number(marks) / Number(maxMarks)) * 100;
    const grade = calculateGrade(percentage);
    updateData = { marks: Number(marks), maxMarks: Number(maxMarks), grade, percentage, examType };
  }

  const [updated] = await db.update(resultsTable).set(updateData).where(eq(resultsTable.id, id)).returning();
  if (!updated) {
    res.status(404).json({ message: "Result not found" });
    return;
  }
  res.json(updated);
});

export default router;
