import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { getAttendance, markAttendance } from "@workspace/api-client-react";
import type { GetAttendanceParams, MarkAttendanceRequest } from "@workspace/api-client-react/src/generated/api.schemas";
import { getAuthHeaders } from "@/lib/utils";

export const ATTENDANCE_KEY = ["attendance"];

export function useAttendance(params: GetAttendanceParams) {
  return useQuery({
    queryKey: [...ATTENDANCE_KEY, params],
    queryFn: () => getAttendance(params, { headers: getAuthHeaders() }),
    enabled: !!params.courseId && !!params.date,
  });
}

export function useMarkAttendance() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (data: MarkAttendanceRequest) => markAttendance(data, { headers: getAuthHeaders() }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ATTENDANCE_KEY }),
  });
}
