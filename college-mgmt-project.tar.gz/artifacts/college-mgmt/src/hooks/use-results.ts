import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { getResults, addResult, updateResult } from "@workspace/api-client-react";
import type { GetResultsParams, AddResultRequest, UpdateResultRequest } from "@workspace/api-client-react/src/generated/api.schemas";
import { getAuthHeaders } from "@/lib/utils";

export const RESULTS_KEY = ["results"];

export function useResults(params: GetResultsParams) {
  return useQuery({
    queryKey: [...RESULTS_KEY, params],
    queryFn: () => getResults(params, { headers: getAuthHeaders() }),
    enabled: !!params.courseId,
  });
}

export function useAddResult() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (data: AddResultRequest) => addResult(data, { headers: getAuthHeaders() }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: RESULTS_KEY }),
  });
}

export function useUpdateResult() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ id, data }: { id: number; data: UpdateResultRequest }) => 
      updateResult(id, data, { headers: getAuthHeaders() }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: RESULTS_KEY }),
  });
}
