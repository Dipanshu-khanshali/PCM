import { useQuery } from "@tanstack/react-query";
import { getDashboardStats } from "@workspace/api-client-react";
import { getAuthHeaders } from "@/lib/utils";

export function useDashboardStats() {
  return useQuery({
    queryKey: ["dashboardStats"],
    queryFn: () => getDashboardStats({ headers: getAuthHeaders() }),
  });
}
