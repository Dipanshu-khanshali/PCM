import { Router } from "express";
import { db } from "@workspace/db";
import { studentsTable, teachersTable, coursesTable, attendanceTable, resultsTable } from "@workspace/db";
import { requireAuth } from "../middlewares/auth.js";
import { desc } from "drizzle-orm";

const router = Router();

router.get("/", requireAuth, async (_req, res) => {
  const [students, teachers, courses, attendance] = await Promise.all([
    db.select().from(studentsTable),
    db.select().from(teachersTable),
    db.select().from(coursesTable),
    db.select().from(attendanceTable),
  ]);

  const recentStudents = await db.select().from(studentsTable).orderBy(desc(studentsTable.createdAt)).limit(5);

  const recentResultsRaw = await db.select().from(resultsTable).orderBy(desc(resultsTable.createdAt)).limit(5);

  res.json({
    totalStudents: students.length,
    totalTeachers: teachers.length,
    totalCourses: courses.length,
    totalAttendance: attendance.length,
    recentStudents,
    recentResults: recentResultsRaw,
  });
});

export default router;
