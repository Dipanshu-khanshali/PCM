import React, { useState } from "react";
import { useCourses } from "@/hooks/use-courses";
import { useStudents } from "@/hooks/use-students";
import { useAttendance, useMarkAttendance } from "@/hooks/use-attendance";
import { PageHeader, Card, Table, Th, Tr, Td, Select, Input, Badge, Button } from "@/components/ui-elements";
import { Loader2, Calendar, BookOpen, Check, X, Clock } from "lucide-react";
import { motion } from "framer-motion";
import { format } from "date-fns";

export default function Attendance() {
  const [selectedCourse, setSelectedCourse] = useState<string>("");
  const [date, setDate] = useState<string>(format(new Date(), 'yyyy-MM-dd'));

  const { data: coursesData } = useCourses();
  const { data: studentsData } = useStudents();
  const { data: attendanceData, isLoading: loadingAttendance, refetch } = useAttendance({
    courseId: selectedCourse ? parseInt(selectedCourse) : undefined,
    date: date
  });
  
  const markAttendance = useMarkAttendance();

  const courses = coursesData?.courses || [];
  // Ideally, API should return students enrolled in the specific course.
  // Using all students for this scaffold.
  const students = studentsData?.students || [];
  const records = attendanceData?.records || [];

  const getStatusForStudent = (studentId: number) => {
    const record = records.find(r => r.studentId === studentId);
    return record?.status || null; // null means unmarked
  };

  const handleMark = async (studentId: number, status: 'present' | 'absent' | 'late') => {
    if (!selectedCourse) return;
    try {
      await markAttendance.mutateAsync({
        studentId,
        courseId: parseInt(selectedCourse),
        date,
        status
      });
      // The invalidation in the hook will refetch the query automatically
    } catch (err) {
      console.error(err);
    }
  };

  const StatusButton = ({ status, activeStatus, onClick, label, icon: Icon, activeClass }: any) => {
    const isActive = status === activeStatus;
    return (
      <button
        onClick={onClick}
        className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium border transition-all ${
          isActive 
            ? activeClass 
            : 'border-white/5 bg-white/[0.02] text-muted-foreground hover:bg-white/5'
        }`}
      >
        <Icon size={14} />
        {label}
      </button>
    );
  };

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
      <PageHeader 
        title="Attendance Register" 
        description="Record and track daily student attendance."
      />

      <Card className="p-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-2xl">
          <div className="space-y-2">
            <label className="text-sm font-medium text-white/80 flex items-center gap-2">
              <BookOpen size={16} className="text-primary" /> Select Course
            </label>
            <Select value={selectedCourse} onChange={(e) => setSelectedCourse(e.target.value)}>
              <option value="" className="bg-background">-- Choose Course --</option>
              {courses.map(c => (
                <option key={c.id} value={c.id} className="bg-background">{c.code} - {c.name}</option>
              ))}
            </Select>
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium text-white/80 flex items-center gap-2">
              <Calendar size={16} className="text-primary" /> Select Date
            </label>
            <Input 
              type="date" 
              value={date} 
              onChange={(e) => setDate(e.target.value)}
              className="bg-black/50"
            />
          </div>
        </div>
      </Card>

      {selectedCourse ? (
        <Card className="p-0 overflow-hidden">
          <div className="p-4 border-b border-white/5 bg-white/[0.02] flex justify-between items-center">
            <h3 className="font-semibold text-white">Student Roster</h3>
            <div className="flex gap-4 text-sm text-muted-foreground">
              <span>Total: {students.length}</span>
              <span>Marked: {records.length}</span>
            </div>
          </div>
          
          <div className="overflow-x-auto">
            <Table>
              <thead>
                <Tr>
                  <Th>Roll No</Th>
                  <Th>Student Name</Th>
                  <Th>Current Status</Th>
                  <Th className="text-right">Mark Attendance</Th>
                </Tr>
              </thead>
              <tbody>
                {students.map(student => {
                  const currentStatus = getStatusForStudent(student.id);
                  return (
                    <Tr key={student.id}>
                      <Td className="font-mono text-muted-foreground">{student.rollNumber}</Td>
                      <Td className="font-medium text-white">{student.name}</Td>
                      <Td>
                        {currentStatus === 'present' && <Badge variant="success">Present</Badge>}
                        {currentStatus === 'absent' && <Badge variant="danger">Absent</Badge>}
                        {currentStatus === 'late' && <Badge variant="warning">Late</Badge>}
                        {!currentStatus && <span className="text-muted-foreground text-xs italic">Unmarked</span>}
                      </Td>
                      <Td className="text-right">
                        <div className="flex items-center justify-end gap-2">
                          <StatusButton 
                            status="present" 
                            activeStatus={currentStatus} 
                            onClick={() => handleMark(student.id, 'present')}
                            label="Present"
                            icon={Check}
                            activeClass="bg-emerald-500/20 text-emerald-400 border-emerald-500/50 shadow-[0_0_10px_rgba(16,185,129,0.2)]"
                          />
                          <StatusButton 
                            status="absent" 
                            activeStatus={currentStatus} 
                            onClick={() => handleMark(student.id, 'absent')}
                            label="Absent"
                            icon={X}
                            activeClass="bg-red-500/20 text-red-400 border-red-500/50 shadow-[0_0_10px_rgba(239,68,68,0.2)]"
                          />
                          <StatusButton 
                            status="late" 
                            activeStatus={currentStatus} 
                            onClick={() => handleMark(student.id, 'late')}
                            label="Late"
                            icon={Clock}
                            activeClass="bg-amber-500/20 text-amber-400 border-amber-500/50 shadow-[0_0_10px_rgba(245,158,11,0.2)]"
                          />
                        </div>
                      </Td>
                    </Tr>
                  );
                })}
              </tbody>
            </Table>
          </div>
        </Card>
      ) : (
        <div className="flex flex-col items-center justify-center p-12 text-muted-foreground border border-dashed border-white/10 rounded-2xl bg-white/[0.01]">
          <BookOpen className="h-12 w-12 mb-4 opacity-20" />
          <p className="text-lg">Select a course to view the roster and mark attendance.</p>
        </div>
      )}
    </motion.div>
  );
}
